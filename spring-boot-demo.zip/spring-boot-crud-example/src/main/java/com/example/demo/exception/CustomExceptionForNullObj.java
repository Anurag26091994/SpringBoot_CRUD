package com.example.demo.exception;

public class CustomExceptionForNullObj extends Exception {
	
	
	public CustomExceptionForNullObj(String msg) {
		// TODO Auto-generated constructor stub
		
		super(msg);
	}
	

}
